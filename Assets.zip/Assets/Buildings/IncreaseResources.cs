using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IncreaseResources : MonoBehaviour
{
    [Header("Amount")]
    public int moneyAmount;
    public int foodAmount;
    public int woodAmount;
    public int stoneAmount;
    public int metalAmount;
    public int militaryPowerAmount;

    [Header("Cost")]
    public int moneyCost;
    public int woodCost;
    public int stoneCost;
    public int metalCost;

    GameObject myCamera;
    Grid grid;

    void Start()
    {
        myCamera = Camera.main.gameObject;
        grid = myCamera.GetComponent<Grid>();
    }

    void AddResources()
    {
        grid.AddMoney(moneyAmount);
        grid.AddFood(foodAmount);
        grid.AddWood(woodAmount);
        grid.AddStone(stoneAmount);
        grid.AddMetal(metalAmount);
        grid.AddMilitaryPower(militaryPowerAmount);
    }
}
