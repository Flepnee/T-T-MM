using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;

public class Grid : MonoBehaviour
{
    [Header("Raycast Plane")]
    GameObject myCamera;
    public LayerMask rayMask;
    public Vector3 cursorPos;
    public float posX;
    public float posY;

    [Header("Projection")]
    public GameObject projection;
    public SpriteRenderer projSprite;

    [Header("Check For Collisions")]
    public bool canPlace;
    public LayerMask disallowedMask;

    [Header("Place Buildings")]
    public GameObject[] buildings;
    public GameObject selectedBuilding;

    [Header("Check If Can Afford")]
    public bool canAfford;
    IncreaseResources rI;

    [Header("Button Selector")]
    public Button[] buttons;
    public int selectedIndex = 1;
    public bool buildingSelected;
    public TextMeshProUGUI[] priceText;

    [Header("Next Turn")]
    public int day = 1;
    public float opacity = 0f;
    bool changingDay;
    public GameObject background;
    public TextMeshProUGUI dayCounter;

    [Header("Resources Screen")]
    public TextMeshProUGUI moneyText;
    public TextMeshProUGUI foodText;
    public TextMeshProUGUI woodText;
    public TextMeshProUGUI stoneText;
    public TextMeshProUGUI metalText;
    public TextMeshProUGUI militaryPowerText;
    public float money;
    public float food;
    public float wood;
    public float stone;
    public float metal;
    public float militaryPower;

    [Header("CameraController")]
    public float moveSpeed = 5f;
    public float maxDistance = 20f;
    public float minSize = 1f;
    public float maxSize = 10f;
    public float scrollSensitivity = 1f;

    [Header("Events")]
    public TMP_Text eventScreenText;
    public GameObject eventScreen;
    bool canOpenScreen = true;

    [Header("Temporary")]
    public Sprite test;

    void Start()
    {
        myCamera = Camera.main.gameObject;

        //Adds a listener to all buttons connected to the script
        for (int i = 0; i < buttons.Length; i++)
        {
            int index = i;
            buttons[i].onClick.AddListener(() => OnButtonClick(index));
        }

        changingDay = false;
        BuildingsPrices();
    }

    void Update()
    {
        MoveCamera();
        ZoomCamera();
        DeselectBuilding();
        OpacityChange();
        ResourcesScreen();
        if (!EventSystem.current.IsPointerOverGameObject()) // Check if mouse is over UI
        {
            AdjustSelectedBuilding();
            AdjustProjection();
            RaycastPlane();
            CheckForCollisions();
            PlaceBuilding();
        }
    }

    void RaycastPlane()
    {
        //Raycast from Camera to Cursor, colliding with a plane to see where the players is pointing
        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out RaycastHit hit, 100.0f, rayMask))
        {
            AdjustPos();
            cursorPos = new Vector3(Mathf.FloorToInt(hit.point.x) + posX, Mathf.FloorToInt(hit.point.y) + posY, 0);
            projection.transform.position = cursorPos;
        }
    }

    void CheckForCollisions()
    {
        if(Physics2D.OverlapBox(projection.transform.position, new Vector2(projection.transform.localScale.x - 0.2f, projection.transform.localScale.y - 0.2f), 0, disallowedMask))
        {
            canPlace = false;
            projSprite.color = new Vector4(0.7f, 0, 0 , 0.5f);
            if(!canAfford)
            {
                projSprite.color = new Vector4(0.7f, 0, 0, 0.5f);
            }
        }
        else
        {
            canPlace = true;
            projSprite.color = new Vector4(0, 0.7f, 0, 0.5f);
            if (canAfford)
            {
                projSprite.color = new Vector4(0, 0.7f, 0, 0.5f);
            }
            else if (!canAfford)
            {
                projSprite.color = new Vector4(0.7f, 0, 0, 0.5f);
            }
        }
    }

    public void AdjustProjection()
    {
        projection.transform.localScale = selectedBuilding.transform.localScale;
    }

    void AdjustPos()
    {
        if (selectedBuilding.transform.localScale.x % 2 == 0)
        {
            posX = 0;
        }
        else
        {
            posX = 0.5f;
        }

        if (selectedBuilding.transform.localScale.y % 2 == 0)
        {
            posY = 0;
        }
        else
        {
            posY = 0.5f;
        }
    }

    void AdjustSelectedBuilding()
    {
        selectedBuilding = buildings[selectedIndex];
    }
    
    void PlaceBuilding()
    {
        CheckIfCanAfford();
        if (Input.GetMouseButtonDown(0) && canPlace && buildingSelected && canAfford)
        {
            money -= rI.moneyCost;
            wood-= rI.woodCost;
            stone -= rI.stoneCost;
            metal -= rI.metalCost;
            Instantiate(selectedBuilding, cursorPos, Quaternion.identity);
        }
    }

    void CheckIfCanAfford()
    {
        rI = selectedBuilding.GetComponent<IncreaseResources>();
        if (money >= rI.moneyCost && wood >= rI.woodCost && stone >= rI.stoneCost && metal >= rI.metalCost)
        {
            canAfford = true;
        }
        else
        {
            canAfford = false;
        }

    }

    void Bankrupt()
    {
        if(money < 0 || wood < 0 || stone < 0 || metal < 0 || food < 0)
        {
            Application.Quit();
        }
    }

    void OnButtonClick(int index)
    {
        projection.SetActive(true);
        selectedIndex = index;
        buildingSelected = true;
    }

    void DeselectBuilding()
    {
        if(Input.GetMouseButtonDown(1)) 
        {
            projection.SetActive(false);
            buildingSelected = false;
        }
    }

    public void NextTurn()
    {
        DisableEventScreen();
        day++;
        dayCounter.text = "Day: " + day;
        opacity = 0;
        background.SetActive(true);
        changingDay = true;
        RandomizeForEvent();
        SendCommand();
    }

    void SendCommand()
    {
        GameObject[] placedBuildings = GameObject.FindGameObjectsWithTag("Building");

        foreach (GameObject obj in placedBuildings)
        {
            obj.SendMessage("AddResources");
        }
    }

    void OpacityChange()
    {
        background.GetComponent<Image>().color = new Vector4(0, 0, 0, opacity);
        dayCounter.color = new Vector4(1, 1, 1, opacity);

        if (changingDay && opacity <= 1.5f)
        {
            opacity += Time.deltaTime;
        }
        else if(opacity >= 0)
        {
            opacity -= Time.deltaTime;
        }

        if(opacity <= 0)
        {
            background.SetActive(false);

            if (canOpenScreen)
            {
                eventScreen.SetActive(true);
                canOpenScreen = false;
            }
        }

        if (opacity >= 1.5f)
        {
            changingDay = false;
        }
    }

    void ResourcesScreen()
    {
        money = Mathf.RoundToInt(money);
        food = Mathf.RoundToInt(food);
        wood = Mathf.RoundToInt(wood);
        stone = Mathf.RoundToInt(stone);
        metal = Mathf.RoundToInt(metal);
        militaryPower = Mathf.RoundToInt(militaryPower);

        moneyText.text = " " + money;
        foodText.text = " " + food;
        woodText.text = " " + wood;
        stoneText.text = " " + stone;
        metalText.text = " " + metal;
        militaryPowerText.text = " " + militaryPower;
    }

    void BuildingsPrices()
    {
        for (int i = 0; i < 16; i++)
        {
            priceText[i].text = "Wood: " + buildings[i].GetComponent<IncreaseResources>().woodCost + ", Stone: " + buildings[i].GetComponent<IncreaseResources>().stoneCost + ", Metal: " + buildings[i].GetComponent<IncreaseResources>().metalCost + ", Money: " + buildings[i].GetComponent<IncreaseResources>().moneyCost;
        }
    }

    public void AddMoney(int amount)
    {
        money += amount;
    }

    public void AddFood(int amount)
    {
        food += amount;
    }

    public void AddWood(int amount)
    {
        wood += amount;
    }

    public void AddStone(int amount)
    {
        stone += amount;
    }

    public void AddMetal(int amount)
    {
        metal += amount;
    }

    public void AddMilitaryPower(int amount)
    {
        militaryPower += amount;
    }

    public void RandomizeForEvent()
    {
        if(day > 9)
        {
            if (food > wood + stone && UnityEngine.Random.Range(1, 8) == 1)
            {
                eventScreenText.text = "Drought Happenend :< \n" + "Food lost: " + food;
                DroughtEvent();
            }
            else if (wood > metal && stone > 50 && UnityEngine.Random.Range(1, 4) == 1)
            {
                eventScreenText.text = "Forest Fire Happenend :<\n" + "Wood lost:" + Mathf.RoundToInt(wood / 2f);
                ForestFireEvent();
            }
            else if (militaryPower > money && UnityEngine.Random.Range(1, 6) == 1)
            {
                eventScreenText.text = "Military Coup Happenend :<\n" + "Gold stolen: " + money;
                CoupEvent();
            }
            else if (UnityEngine.Random.Range(1, 32) == 1) 
            {
                eventScreenText.text = "Bug Infestation Happened :<\n" + "Wood lost: " + Mathf.RoundToInt(wood - 10f);
                InfestationEvent();
            }
            else if (UnityEngine.Random.Range(1, 32) == 1) 
            {
                eventScreenText.text = "A Mine Collapsed :<\n" + "Stone lost: " + Mathf.RoundToInt(stone - 10f);
                MineCollapseEvent();
            }
            else if (UnityEngine.Random.Range(1, 32) == 1) 
            {
                eventScreenText.text = "Your village has been pillaged :<\n" + "Wood lost: " + Mathf.RoundToInt(money - 10f);
                PillageEvent();
            }
            else if (UnityEngine.Random.Range(1, 32) == 1) 
            {
                eventScreenText.text = "People are migrating in masses :<\n" + "Food lost: " + Mathf.RoundToInt(food - 10f);
                MassMigrationEvent();
            }
            else
            {
                eventScreenText.text = "No event but this still dobe event text ya knowww *wink wink*";
            }
            canOpenScreen = true;
        }
    }

    public void DisableEventScreen()
    {
        eventScreen.SetActive(false);
        UnityEngine.Debug.Log("Event Scren Off ;-;");
    }

    void DroughtEvent()
    {
        AddFood(-(int)(food));
    }

    void ForestFireEvent()
    {
        AddWood(-(int)(wood / 2f));
    }

    void CoupEvent()
    {
        AddMoney(-(int)(money));
    }

    void InfestationEvent()
    {
        AddWood(-(int)(wood - 10f));
    }

    void MineCollapseEvent()
    {
        AddStone(-(int)(stone - 10f));
    }

    void PillageEvent()
    {
        AddMoney(-(int)(money - 10f));
    }

    void MassMigrationEvent()
    {
        AddFood(-(int)(food - 10f));
    }

    void MoveCamera()
    {
        if (Input.GetMouseButton(2))
        {
            float mouseX = Input.GetAxis("Mouse X");
            float mouseY = Input.GetAxis("Mouse Y");

            Vector3 moveDirection = new Vector3(-mouseX, -mouseY, 0f) * moveSpeed * Time.deltaTime;

            if (Mathf.Abs(transform.position.x + moveDirection.x) <= maxDistance && Mathf.Abs(transform.position.y + moveDirection.y) <= maxDistance)
            {
                transform.Translate(moveDirection);
            }
        }
    }

    void ZoomCamera()
    {
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll != 0f)
        {
            Camera camera = Camera.main;
            float newSize = camera.orthographicSize - scroll * scrollSensitivity;
            newSize = Mathf.Clamp(newSize, minSize, maxSize);
            camera.orthographicSize = newSize;
        }
    }
}